# Game "Space Invaders"

Version 2.0
Developer Rogov Artemy (artemiyrogov1@gmail.com)

## Description

This app is an implementation of the game SPACE INVADERS with acceleration of free fall and the player is in some type of "pit".

## Requirements

* `PyQT5` (installing by pip)

## Structure

Main module (GUI and implementation of the game): `SpaceInvaders.py`

Modules: `Enemies.py`, `Values.py`, `Levels.py`, `Images.py`

Tests: `test_Enemies.py`

## How to play
for example you have levels: `level1.txt`, `level2.txt`
using command line you can run the game

`python SpaceInvaders.py NAME level2.txt level1.txt`

you will play at first `level2.txt`, after `level1.txt` and your name in scoreboard will be NAME

### Controlling

* `Key left`, `Key right` - To control cart

* `Space` - To fire

* `P` - To pause the game

* `S` - To save the game

* `V` - To load the last saving

* `O` - To see a scoreboard during a game (pause_mode activating automatically)

#### Details of implementation

`Enemies.py` contains information about all classes using in this game (invaders, bullets, cart, etc.)

`Values.py` contains all the constants using in this game

`Levels.py` parses information about levels from text files

`Images.py` contains all images ^-^


You can make your own levels. You should only build new level`number`.txt using next sample:

		[easyinvader]
		damage = value (from 0 to infinity :) )
		lives = value (from 0 to infinity :) )
		type = value (from 1 to 3; 1 - aim on cart, 2 - aim near cart, 3 - random aim)

		[mediuminvader]
		damage = value
		lives = value
		type = value

		[hardinvader]
		damage = value
		lives = value
		type = value

        [first_raw_enemies]
        easy = count
        [second_raw_enemies]
        medium = count
        hard = count
        easy = count
        [third_raw_enemies]
        hard = count
        medium = count # if you don`t add information about count of some type of enemie nothing will happend

		[level]
		weight_cart = value (from 1 to 20, if it is very small, you will be very light, if it is very big, you won`t have opportunity to normally move)
		angle_cart = value (from 30 to 150)
		interval_cart = value (in ms, value=1000 - interval is 1 second)
		lives_cart = value (from 1 to infinity :) )
		probability = value (in percents from 0 to 100, chance of dropping bonus after fire invader)
            lives_bonus = value (count of lives bonus will give you)
            bullet_bonus = value (count of additional power for next one bullet)
            interval_mystery_ship = value (in ms, value=1000 - interval is 1 second)
